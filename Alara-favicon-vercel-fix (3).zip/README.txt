WHY THE VERCEL FAVICON WAS MISSING: the currently deployed page has no rel=icon links in its HTML head, and requests for /favicon.ico and favicon PNGs return 404. The header logo itself loads from Google Drive; this package adds the browser-tab/home-screen logo.

UPLOAD ALL FILES IN THIS PACKAGE TO THE ROOT of the GitHub repository (same folder as index.html), replacing index.html. Do not put the favicon files in a subfolder. Commit the changes and let Vercel redeploy. If the tab icon remains cached, hard-refresh or reopen the site in a private tab.
